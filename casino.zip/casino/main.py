import io
import discord
from discord.ext import commands
from discord import app_commands
import httpx
import os
import json
import random
from deep_translator import GoogleTranslator, DeeplTranslator
import asyncio
import urllib.parse
from linkvertise_bypasser import bypass as link_bypass
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from datetime import datetime
from game2.engine import CasinoEngine
from game2.factory import render_table, render_dice_result, render_dice_animation, render_poker_table
from game2.view import BJView, BaccaratView, TaiXiuView, PokerView

CHIP_EMOJI = "🪙"
DATA_PATH = "/storage/emulated/0/Download/casino/game2/chip.json"
STOCKS = {
    "BTC": {"name": "BITCOIN", "desc": "Bien dong cuc manh.", "volatility": 0.15},
    "GME": {"name": "GAMESTOP", "desc": "Co phieu dau co.", "volatility": 0.25},
    "TSL": {"name": "TESLA", "desc": "Bien dong on dinh.", "volatility": 0.05}
}


# 1. Hàm đọc file cực nhẹ
def lay_txt(ten_file):
    if os.path.exists(ten_file):
        with open(ten_file, "r", encoding="utf-8") as f:
            return f.read().strip()
    return None

TOKEN = lay_txt("TOKEN.txt")
KEY_GEMINI = lay_txt("API_KEY.txt")

class MyBot(discord.Client):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True 
        super().__init__(intents=intents)
        # Viết dính liền trên 1 dòng như thế này:
        self.tree = app_commands.CommandTree(self)
        self.model_name = "models/gemini-1.5-flash" 

    async def setup_hook(self):
        # Tăng timeout lên cực cao để tránh lỗi như trong ảnh bạn gửi
        timeout_config = httpx.Timeout(150.0, connect=80.0)
        async with httpx.AsyncClient(timeout=timeout_config) as client:
            try:
                # Tự động quét model đang sống trong tài khoản
                list_url = f"https://generativelanguage.googleapis.com/v1beta/models?key={KEY_GEMINI}"
                res = await client.get(list_url)
                if res.status_code == 200:
                    models = res.json().get("models", [])
                    for m in models:
                        if "generateContent" in m.get("supportedGenerationMethods", []):
                            self.model_name = m["name"]
                            break
            except:
                print("Mạng lag , dùng tạm model mặc định flash.")

        await self.tree.sync()
        print(f"Bot đã lên! Model đang dùng: {self.model_name}")
   
def update_stock_prices():
    prices = get_stock_prices()
    for k in prices:
        # Bien dong ngau nhien dua tren do bien dong (volatility)
        change = random.uniform(-STOCKS[k]["volatility"], STOCKS[k]["volatility"])
        prices[k] = max(1000, int(prices[k] * (1 + change))) # Gia toi thieu 1000
    with open("stock_data.json", "w") as f:
        json.dump(prices, f)
    return prices

def is_admin(user_id):
    admin_path = "/storage/emulated/0/Download/casino/admin.txt"
    if not os.path.exists(admin_path):
        return False
    with open(admin_path, "r", encoding="utf-8") as f:
        # Đọc tất cả các ID và bỏ khoảng trắng/dòng trống
        admins = [line.strip() for line in f.readlines() if line.strip()]
    return str(user_id) in admins

def get_top_players(limit=10):
    if not os.path.exists(DATA_PATH):
        return []
    
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    # Lấy danh sách players và sắp xếp theo số chip giảm dần
    players = data.get("players", {})
    sorted_players = sorted(
        players.items(), 
        key=lambda item: item[1].get("chips", 0), 
        reverse=True
    )
    return sorted_players[:limit]


def get_user_chips(user_id):
    if not os.path.exists(DATA_PATH):
        os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
        with open(DATA_PATH, "w") as f:
            json.dump({"players": {}}, f)
    
    with open(DATA_PATH, "r") as f:
        data = json.load(f)
    
    uid = str(user_id)
    if uid not in data["players"]:
        return 10000 # Tặng 10k chip cho người mới
    return data["players"][uid]["chips"]

def update_chips(user_id, amount):
    user_id = str(user_id)
    with open(DATA_PATH, "r") as f:
        data = json.load(f)
    
    if user_id not in data["players"]:
        data["players"][user_id] = {"chips": 0}
    
    # Cộng dồn số chip mới vào số cũ
    data["players"][user_id]["chips"] += amount
    
    with open(DATA_PATH, "w") as f:
        json.dump(data, f, indent=4)

def log_game_history(user_id, game_name, amount, result_type):
    """
    Lưu lịch sử 10 ván gần nhất của người chơi.
    - amount: số chip nhận được hoặc mất đi (VD: +5000, -5000)
    - result_type: Chuỗi hiển thị kết quả (VD: "THẮNG", "THUA", "JACKPOT")
    """
    uid = str(user_id)
    try:
        with open(DATA_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        if uid not in data["players"]:
            return # Người chơi không tồn tại thì không ghi

        # Khởi tạo list history nếu chưa có trong data người chơi
        if "history" not in data["players"][uid]:
            data["players"][uid]["history"] = []
            
        # Định dạng dòng lịch sử: [Giờ] Tên Game: Kết quả (Số tiền)
        from datetime import datetime
        time_str = datetime.now().strftime("%H:%M")
        
        # Dùng ký hiệu + hoặc - để tí nữa hiển thị màu sắc trong lệnh /history
        prefix = "+" if amount >= 0 else ""
        entry = f"[{time_str}] {game_name}: {result_type} ({prefix}{amount:,})"
        
        # Chèn vào đầu danh sách (ván mới nhất lên trên)
        data["players"][uid]["history"].insert(0, entry)
        
        # Chỉ giữ lại tối đa 10 ván gần nhất
        data["players"][uid]["history"] = data["players"][uid]["history"][:10]
        
        with open(DATA_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
            
    except Exception as e:
        print(f"Lỗi ghi lịch sử: {e}")


def mask_circle(img, size):
    mask = Image.new("L", size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0) + size, fill=255)
    output = img.copy()
    output.putalpha(mask)
    return output

# Alias để tránh lỗi ImportError từ main.py cũ
def get_event():
    return roll_3_sides()

def update_player(uid, coin_change=0):
    uid = str(uid)
    user_data = get_data(uid)
    user_data["coin"] += coin_change
    
    data = {}
    if os.path.exists(DB_PATH):
        with open(DB_PATH, "r") as f: data = json.load(f)
    data[uid] = user_data
    save_data(data)
    return user_data

    # Logic dich khi nhan giu tin nhan
    async def dich_context_menu(self, interaction: discord.Interaction, message: discord.Message):
        await interaction.response.defer(ephemeral=True)
        try:
            if message.content:
                # Dung GoogleTranslator cho on dinh tren Termux
                dich = GoogleTranslator(source='auto', target='vi').translate(message.content)
                await interaction.followup.send(f"--- BAN DICH ---\n{dich}", ephemeral=True)
            else:
                await interaction.followup.send("Tin nhan khong co chu de dich.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Loi: {str(e)}", ephemeral=True)
       
bot = MyBot()

@bot.tree.command(name="poker", description="Texas Hold'em Poker - Đối kháng Nhà Cái")
async def poker(interaction: discord.Interaction, bet: int):
    if bet < 1000:
        return await interaction.response.send_message("Mức cược tối thiểu là 1,000 chip!", ephemeral=True)
        
    current_chips = get_user_chips(interaction.user.id)
    if current_chips < bet:
        return await interaction.response.send_message(f"Bạn không đủ chip! (Có: {current_chips:,})", ephemeral=True)

    update_chips(interaction.user.id, -bet)
    await interaction.response.defer()

    # Khởi tạo View với đầy đủ tham số như Tài Xỉu/Blackjack của ông
    view = PokerView(
        user_id=interaction.user.id,
        bet=bet,
        engine=CasinoEngine,
        update_func=update_chips,
        log_history=log_game_history
    )

    # Render ảnh Pre-flop ban đầu (Dealer úp, Community chưa có gì)
    img_bin = render_poker_table(view.p_hand, view.d_hand, [], "PRE-FLOP", True)
    file = discord.File(img_bin, filename="poker.png")

    await interaction.followup.send(
        content=f"💎 **Poker** | Người chơi: {interaction.user.mention} | Cược: {bet} {CHIP_EMOJI}",
        file=file,
        view=view
    )

@bot.tree.command(name="history", description="Xem nhật ký 10 ván cược gần nhất")
async def history(interaction: discord.Interaction):
    uid = str(interaction.user.id)
    
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    user_data = data["players"].get(uid, {})
    h_list = user_data.get("history", [])
    
    if not h_list:
        return await interaction.response.send_message("🏢 Quý khách chưa có giao dịch nào tại Casino!", ephemeral=True)

    formatted_history = ""
    for entry in h_list:
        if "(+" in entry:
            formatted_history += f"◈ {entry}\n" # Dòng màu xanh
        else:
            formatted_history += f"◈ {entry}\n" # Dòng màu đỏ

    embed = discord.Embed(
        title="NHẬT KÝ ĐẠI GIA",
        description=f"\n{formatted_history}",
        color=0x3498db
    )
    embed.set_footer(text=f"Yêu cầu bởi: {interaction.user.name}")
    
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="ranking", description="Bảng xếp hạng đại gia Casino")
async def ranking(interaction: discord.Interaction):
    await interaction.response.defer()
    
    top_list = get_top_players(5)
    
    if not top_list:
        return await interaction.followup.send("Hệ thống chưa ghi nhận dữ liệu thành viên.")

    embed = discord.Embed(
        title="👑 BẢNG XẾP HẠNG THÀNH VIÊN THƯỢNG LƯU 👑",
        description="Những gương mặt quyền lực nhất trong giới thượng lưu Casino.",
        color=0xffd700 # Màu vàng Gold
    )

    leaderboard_text = ""
    for i, (uid, info) in enumerate(top_list, 1):
        # Tìm tên người dùng (ưu tiên cache, nếu không có thì fetch từ Discord API)
        user = bot.get_user(int(uid))
        if not user:
            try:
                user = await bot.fetch_user(int(uid))
            except:
                user = None

        name = user.name if user else f"Thành viên ẩn danh ({uid})"
        chips = info.get("chips", 0)
        
        # Thiết kế icon thứ hạng
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"` {i} ` "
        
        # Sử dụng CHIP_EMOJI trong dòng hiển thị
        leaderboard_text += f"{medal} **{name}**\n ➥ {CHIP_EMOJI} `{chips:,}` CHIPS\n\n"

    embed.add_field(name="Vị thế các đại gia", value=leaderboard_text, inline=False)
    
    # Gán thời gian cập nhật đúng chuẩn
    embed.timestamp = datetime.now()
    embed.set_footer(text="Dữ liệu thời gian thực")
    
    # Thêm ảnh server vào góc trên cho sang trọng
    if interaction.guild.icon:
        embed.set_thumbnail(url=interaction.guild.icon.url)

    await interaction.followup.send(embed=embed)

@bot.tree.command(name="daily", description="Nhận phúc lợi thành viên hàng ngày")
async def daily(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=False)
    uid = str(interaction.user.id)
    
    # Đọc dữ liệu từ hệ thống lưu trữ
    with open(DATA_PATH, "r") as f:
        data = json.load(f)
    
    # Khởi tạo dữ liệu nếu là người dùng mới
    if uid not in data["players"]:
        data["players"][uid] = {"chips": 10000, "last_daily": ""}
    
    user_data = data["players"][uid]
    
    # Kiểm tra điều kiện thời gian từ CasinoEngine
    if not CasinoEngine.can_daily(user_data.get("last_daily", "")):
        return await interaction.response.send_message(
            "Giao dịch thất bại. Quý khách đã nhận phúc lợi trong ngày hôm nay. Vui lòng quay lại sau 00:00.", 
            ephemeral=True
        )

    # Tính toán giá trị thưởng
    base_reward = 2000
    luck_bonus = random.randint(1, 1000)
    total_reward = base_reward + luck_bonus
    
    # Cập nhật số dư và thời gian điểm danh
    data["players"][uid]["chips"] += total_reward
    data["players"][uid]["last_daily"] = datetime.now().strftime("%Y-%m-%d")
    
    with open(DATA_PATH, "w") as f:
        json.dump(data, f, indent=4)

    # Giao diện thông báo chuyên nghiệp
    embed = discord.Embed(
        title="PHÚC LỢI THÀNH VIÊN",
        description=f"Hệ thống xác nhận sự hiện diện của quý khách: **{interaction.user.display_name}**",
        color=0xffd700  # Gold
    )
    embed.add_field(name="Mức thưởng cơ bản", value=f"{base_reward:,}, {CHIP_EMOJI}", inline=True)
    embed.add_field(name="Thưởng may mắn", value=f"+{luck_bonus:,}, {CHIP_EMOJI}", inline=True)
    embed.add_field(name="Tổng tín dụng nhận được", value=f"{total_reward:,}, {CHIP_EMOJI}", inline=False)
    embed.set_footer(text="Cảm ơn quý khách đã lựa chọn dịch vụ của chúng tôi.")
    
    await interaction.followup.send(embed=embed)

@bot.tree.command(name="taixiu", description="Trò chơi Tài Xỉu - Nổ hũ Jackpot 100M")
async def dice(interaction: discord.Interaction, bet: int):
    # 1. Kiểm tra số dư (Nên dùng tối thiểu 1000 chip để tránh spam)
    if bet <= 0:
        return await interaction.response.send_message("Tiền cược phải lớn hơn 0!", ephemeral=True)
        
    current_chips = get_user_chips(interaction.user.id)
    if current_chips < bet:
        return await interaction.response.send_message(f"Bạn không đủ chip! (Hiện có: {current_chips:,})", ephemeral=True)

    # Trừ tiền ngay khi đặt cược để tránh BUG người chơi thoát ngang
    update_chips(interaction.user.id, -bet)

    # 2. Defer để tránh lỗi Interaction Timeout trên Termux
    await interaction.response.defer()

    # 3. Hiển thị hiệu ứng xúc xắc đang lắc
    img_bin = render_dice_animation()
    file = discord.File(img_bin, filename="rolling.gif")

    # 4. TRUYỀN ĐỦ THAM SỐ vào View (ID, Tiền cược, Engine, Hàm Update, Hàm History)
    view = TaiXiuView(
        user_id=interaction.user.id, 
        bet_amount=bet, 
        engine=CasinoEngine,        # Phải truyền class này để View gọi hàm check_taixiu
        update_chips=update_chips, 
        log_history=log_game_history # Truyền hàm ghi nhật ký ván đấu
    )
    
    await interaction.followup.send(
        content=f"💎 **TÀI & XỈU** | Người chơi: {interaction.user.mention} | Cược: **{bet:,}** {CHIP_EMOJI}\n*Chọn Tài hoặc Xỉu để mở bát!*",
        file=file,
        view=view
    )



@bot.tree.command(name="chat", description="message to AI")
async def chat(interaction: discord.Interaction, noidung: str):
    await interaction.response.defer()

    url = f"https://generativelanguage.googleapis.com/v1beta/{bot.model_name}:generateContent?key={KEY_GEMINI}"
    payload = {"contents": [{"parts": [{"text": noidung}]}]}
    
    # Cơ chế thử lại 3 lần nếu dính ConnectTimeout
    for i in range(3):
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                response = await client.post(url, json=payload)
                if response.status_code == 200:
                    data = response.json()
                    ket_qua = data["candidates"][0]["content"]["parts"][0]["text"]
                    return await interaction.followup.send(f"**Bạn:** {noidung}\n**AI:** {ket_qua[:1900]}")
                else:
                    msg = response.json().get("error", {}).get("message", "Lỗi lạ")
                    return await interaction.followup.send(f"Lỗi Google: {msg}")
        except (httpx.ConnectTimeout, httpx.ReadTimeout):
            if i < 2: 
                await asyncio.sleep(2) # Đợi 2 giây rồi thử lại
                continue
            await interaction.followup.send("Mạng quá yếu, không thể kết nối tới Google API.")
        except Exception as e:
            return await interaction.followup.send(f"Lỗi hệ thống: {str(e)}")

@bot.tree.command(name="baccarat", description="Chơi Baccarat (Đếm nút)")
@app_commands.describe(bet="Số chip ông muốn cược")
async def baccarat(interaction: discord.Interaction, bet: int):
    # 1. Defer ngay lập tức để tránh lỗi 10062 (Unknown Interaction)
    await interaction.response.defer(ephemeral=False) 

    uid = interaction.user.id
    current_chips = get_user_chips(uid)
    
    if bet <= 0:
        return await interaction.followup.send("Cược ít nhất 1 chip chứ!", ephemeral=True)
    if current_chips < bet:
        return await interaction.followup.send(f"Không đủ chip! Ông còn {current_chips} {CHIP_EMOJI}.", ephemeral=True)

    update_chips(uid, -bet)
    eng = CasinoEngine()
    p_hand = eng.draw(2)
    d_hand = eng.draw(2)
    
    # Xử lý ảnh tốn thời gian nên để sau defer là chuẩn
    img_data = render_table(p_hand, d_hand, hide_dealer=True)
    file = discord.File(fp=img_data, filename="baccarat.png") # Bỏ io.BytesIO()

    view = BaccaratView(
        user_id=interaction.user.id, 
        p_hand=p_hand, 
        d_hand=d_hand, 
        bet=bet, 
        engine=eng, 
        update_func=update_chips, 
        log_history=log_game_history
    )


    # 2. Dùng followup.send thay vì response.send_message vì đã defer
    await interaction.followup.send(
        content=f"💎 **Baccarat** | Người chơi: {interaction.user.mention} | Cược: {bet} {CHIP_EMOJI}",
        file=file,
        view=view
    )

@bot.tree.command(name="blackjack", description="Sòng bài Blackjack Pixel")
async def blackjack(interaction: discord.Interaction, bet: int):
    # 1. Defer ngay để tránh lỗi 3s trên Termux
    await interaction.response.defer()
    
    if bet <= 0:
        return await interaction.response.send_message(
            f"❌ Cược cho tử tế xem nào! Số chip phải lớn hơn 0.", 
            ephemeral=True
        )

    from game2.factory import render_table 
    from game2.engine import CasinoEngine

    # 2. Kiểm tra chip (Đại gia phải có đủ tiền mới được ngồi bàn)
    chips = get_user_chips(interaction.user.id)
    if chips < bet:
        return await interaction.followup.send(f"❌ không đủ chip! (Hiện có: {chips})")

    # 3. Trừ chip ngay khi bắt đầu ván bài (Luật sòng bài chuẩn)
    update_chips(interaction.user.id, -bet)

    # 4. Khởi tạo Engine và chia 2 lá đầu tiên
    engine = CasinoEngine()
    p_hand = engine.draw(2)
    d_hand = engine.draw(2)

    # 5. Vẽ ảnh bàn chơi
    img_bin = render_table(p_hand, d_hand) 
    file = discord.File(img_bin, filename="blackjack.png")

    # 6. Tạo View với đầy đủ 6 tham số ông đã viết ở view.py
    view = BJView(
        user_id=interaction.user.id, 
        p_hand=p_hand, 
        d_hand=d_hand, 
        engine=engine, 
        bet=bet, 
        update_func=update_chips,
        log_history=log_game_history  # THÊM THAM SỐ NÀY ĐỂ GHI NHẬT KÝ 
    )
    
    await interaction.followup.send(
        content=f"💎 **Blackjack** | Người chơi: {interaction.user.mention} | Cược: {bet} {CHIP_EMOJI}",
        file=file,
        view=view
    )

@bot.tree.command(name="givechip", description="Tặng chip cho người chơi khác")
@app_commands.describe(member="Người ông muốn tặng chip", value="Số chip muốn tặng")
async def giftchip(interaction: discord.Interaction, member: discord.Member, value: int):
    # 1. Kiểm tra cơ bản
    if member.id == interaction.user.id:
        return await interaction.response.send_message(" không thể tự tặng chip ", ephemeral=True)
    
    if value <= 0:
        return await interaction.response.send_message("Số chip tặng phải lớn hơn 0 ", ephemeral=True)

    # Đợi một chút để xử lý dữ liệu
    await interaction.response.defer()

    uid_sender = interaction.user.id
    uid_receiver = member.id
    
    # 2. Kiểm tra số dư người gửi
    sender_chips = get_user_chips(uid_sender)
    
    if sender_chips < value:
        return await interaction.followup.send(
            f"không đủ chip rồi! Hiện có: {sender_chips:,} không thể thực hiện giao dịch {CHIP_EMOJI}, {value:,} {CHIP_EMOJI}.", 
            ephemeral=True
        )

    # 3. Thực hiện chuyển tiền
    try:
        # Trừ tiền người gửi
        update_chips(uid_sender, -value)
        # Cộng tiền người nhận
        update_chips(uid_receiver, value)

        # 4. Tạo Embed thông báo giao dịch thành công
        embed = discord.Embed(
            title="💸 GIAO DỊCH THÀNH CÔNG",
            description=f"Một thương vụ chuyển nhượng chip vừa diễn ra!",
            color=0x00ff7f, # Màu xanh lá của tiền
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Người gửi", value=interaction.user.mention, inline=True)
        embed.add_field(name="Người nhận", value=member.mention, inline=True)
        embed.add_field(name="Số lượng chuyển", value=f"**{value:,}** {CHIP_EMOJI}", inline=False)
        embed.add_field(name="Số dư còn lại", value=f"{sender_chips - value:,} {CHIP_EMOJI}", inline=False)
        
        embed.set_thumbnail(url="https://media.discordapp.net/stickers/1318517213166043168.png?size=160") # Icon túi tiền hoặc gì đó
        embed.set_footer(text=f"ID Giao dịch: {interaction.id}")

        await interaction.followup.send(content=f"{member.mention} chúc mừng!", embed=embed)

    except Exception as e:
        # Nếu lỗi thì hoàn tiền (trong trường hợp update_chips bị fail giữa chừng)
        # Nhưng với hàm json của ông thì hiếm khi lỗi này xảy ra
        await interaction.followup.send(f"Đã xảy ra lỗi khi xử lý giao dịch: {e}", ephemeral=True)

@bot.tree.context_menu(name="dich")
async def dich(interaction: discord.Interaction, message: discord.Message):
    # Chi hien thi ket qua cho nguoi dung
    await interaction.response.defer(ephemeral=True)

    try:
        # 1. Không quét history, lấy luôn message.content từ tham số truyền vào
        if not message.content:
            return await interaction.followup.send("Tin nhắn này không có chữ để dịch.", ephemeral=True)

        # 2. Dịch luôn nội dung đó
        translated = GoogleTranslator(source='auto', target='vi').translate(message.content)

        await interaction.followup.send(
            f"{translated}",
            ephemeral=True
        )

    except Exception as e:
        await interaction.followup.send(f"[LOI] Không thể dịch: {str(e)}", ephemeral=True)

@bot.tree.command(name="addchip", description="Buff chip cho bản thân hoặc người khác (Chỉ dành cho Admin)")
@app_commands.describe(value="Số lượng chip muốn tặng (có thể ghi số âm để trừ)", member="Người muốn tặng (để trống nếu tặng chính mình)")
async def buffchip(interaction: discord.Interaction, value: int, member: discord.Member = None):
    # 1. Kiểm tra quyền Admin
    if not is_admin(interaction.user.id):
        return await interaction.response.send_message("Ông không có quyền hạn để dùng lệnh này! ", ephemeral=True)

    await interaction.response.defer(ephemeral=True) # Defer để xử lý file
    
    target = member or interaction.user
    target_id = target.id
    
    # 2. Cập nhật chip vào file JSON
    # Sử dụng hàm update_chips ông đã có sẵn trong main.py
    try:
        update_chips(target_id, value)
        current_chips = get_user_chips(target_id)
        
        # 3. Tạo Embed thông báo cho chuyên nghiệp
        embed = discord.Embed(
            title="✨ HÀNH ĐỘNG BUFF CHIP",
            color=discord.Color.gold() if value > 0 else discord.Color.red(),
            timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Người thực hiện", value=interaction.user.mention, inline=True)
        embed.add_field(name="Người nhận", value=target.mention, inline=True)
        embed.add_field(name="Số lượng", value=f"{'+' if value > 0 else ''}{value:,} {CHIP_EMOJI}", inline=False)
        embed.add_field(name="Số dư hiện tại", value=f"{current_chips:,} {CHIP_EMOJI}", inline=False)
        embed.set_footer(text="Hệ thống Casino Admin")

        await interaction.followup.send(embed=embed, ephemeral=True)
        
        # (Tùy chọn) Thông báo công khai nhưng không tag để tránh làm phiền
        # await interaction.channel.send(f"🏦 Ngân hàng đã điều chỉnh số dư của **{target.display_name}**.")

    except Exception as e:
        await interaction.followup.send(f"Lỗi khi cập nhật dữ liệu: {e}", ephemeral=True)

@bot.tree.command(name="chip", description="Xem số chip đang có")
async def mychip(interaction: discord.Interaction):
    uid = interaction.user.id
    # Sửa get_user_stats thành get_user_chips
    chips = get_user_chips(uid) 
    await interaction.response.send_message(f"Hiện đang có: **{chips}** {CHIP_EMOJI}", ephemeral=True)


if TOKEN:
    bot.run(TOKEN)
