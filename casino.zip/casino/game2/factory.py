from PIL import Image, ImageSequence
import io, os

# ĐƯỜNG DẪN TUYỆT ĐỐI ĐỂ TRÁNH LỖI FILE NOT FOUND
PATH = "/storage/emulated/0/Download/casino/game2/assets/"

def get_card_img(card_code):
    """Cắt bài từ ảnh bobai.png theo vị trí thực tế trong ảnh mới nhất"""
    full_deck = Image.open(f"{PATH}bobai.png").convert("RGBA")
    w, h = full_deck.size
    cw, ch = w // 13, h // 4 # 13 cột (A->K), 4 hàng (chất bài)
    
    # VỊ TRÍ HÀNG THEO ẢNH 1000030759.png:
    # Hàng 0: Chuồn (c), Hàng 1: Rô (d), Hàng 2: Bích (s), Hàng 3: Cơ (h)
    suits = {'c': 0, 'd': 1, 's': 2, 'h': 3}
    
    # VỊ TRÍ CỘT: Thứ tự từ Át (A) đến Già (K) từ trái sang phải
    ranks = {
        'A': 0, '2': 1, '3': 2, '4': 3, '5': 4, '6': 5, '7': 6, 
        '8': 7, '9': 8, '10': 9, 'J': 10, 'Q': 11, 'K': 12
    }
    
    suit_char = card_code[0].lower()
    rank_char = card_code[1:].upper()
    
    row = suits[suit_char]
    col = ranks[rank_char]
    
    # Cắt chính xác tọa độ trên Sprite Sheet
    return full_deck.crop((col * cw, row * ch, (col + 1) * cw, (row + 1) * ch))

def render_table(p_hand, d_hand, hide_dealer=True):
    """Sắp xếp bài theo 2 hàng: Dealer trên, Player dưới như ảnh kết quả"""
    # Sử dụng nền Casino resize 800x500
    bg = Image.open(f"{PATH}bg_casino.png").convert("RGBA").resize((800, 500))
    
    # --- VẼ HÀNG DEALER (Hàng trên) ---
    for i, card in enumerate(d_hand):
        if hide_dealer and i == 0:
            # Lá đầu tiên úp xuống nếu ván đang chơi
            img = Image.open(f"{PATH}matsau.png").convert("RGBA")
        else:
            img = get_card_img(card)
        
        card_img = img.resize((120, 170))
        # Tọa độ y=50 cho hàng trên, i*130 để bài xếp cạnh nhau
        bg.paste(card_img, (150 + i*130, 50), card_img)
        
    # --- VẼ HÀNG PLAYER (Hàng dưới) ---
    for i, card in enumerate(p_hand):
        img = get_card_img(card)
        card_img = img.resize((120, 170))
        # Tọa độ y=280 cho hàng dưới
        bg.paste(card_img, (150 + i*130, 280), card_img)
    
    buf = io.BytesIO()
    bg.save(buf, format="PNG")
    buf.seek(0)
    return buf # Trả về BytesIO để gửi qua Discord


def get_dice_static(number):
    """Cắt mặt xúc xắc từ ảnh xanh dice_blue.png (3 cột x 2 hàng)"""
    # Sử dụng đúng file dice_blue.png mới của ông
    sheet = Image.open(os.path.join(PATH, "dice_blue.png")).convert("RGBA")
    sw, sh = sheet.size
    dw, dh = sw // 3, sh // 2 # Chia làm 3 cột và 2 hàng
    
    idx = number - 1
    col, row = idx % 3, idx // 3
    
    # Tính toán tọa độ cắt
    left = col * dw
    top = row * dh
    right = (col + 1) * dw
    bottom = (row + 1) * dh
    
    return sheet.crop((left, top, right, bottom))

def render_dice_animation():
    """Tạo ảnh GIF 3 viên xúc xắc trắng đang lắc trên nền bg_casino.png"""
    bg = Image.open(os.path.join(PATH, "bg_casino.png")).convert("RGBA").resize((800, 400))
    # Sử dụng file dice_white.gif mới
    dice_gif = Image.open(os.path.join(PATH, "dice_white.gif"))
    
    frames = []
    for frame in ImageSequence.Iterator(dice_gif):
        frame = frame.convert("RGBA").resize((120, 120))
        new_frame = bg.copy()
        
        # Dán 3 viên trắng đang lắc ở các vị trí trung tâm
        new_frame.paste(frame, (200, 140), frame)
        new_frame.paste(frame, (340, 140), frame)
        new_frame.paste(frame, (480, 140), frame)
        frames.append(new_frame)
    
    img_bin = io.BytesIO()
    # Lưu lại thành GIF động, lấy duration gốc từ dice_white.gif
    frames[0].save(
        img_bin, 
        format="GIF", 
        save_all=True, 
        append_images=frames[1:], 
        duration=dice_gif.info.get('duration', 100), 
        loop=0
    )
    img_bin.seek(0)
    return img_bin

def render_dice_result(results):
    """Vẽ kết quả 3 viên xúc xắc xanh tĩnh từ dice_blue.png"""
    bg = Image.open(os.path.join(PATH, "bg_casino.png")).convert("RGBA").resize((800, 400))
    
    for i, res in enumerate(results):
        # res là kết quả từ engine (1-6)
        dice = get_dice_static(res).resize((130, 130))
        # Căn chỉnh 3 viên nằm ngang trên nền
        bg.paste(dice, (180 + i*160, 135), dice)
    
    img_bin = io.BytesIO()
    bg.save(img_bin, format="PNG")
    img_bin.seek(0)
    return img_bin

def render_poker_table(p_hand, d_hand, community, stage, hide_dealer=True):
    # Sử dụng nền Casino 800x600 để đủ chỗ cho 3 hàng
    bg = Image.open(f"{PATH}bg_casino.png").convert("RGBA").resize((800, 600))
    
    # 1. HÀNG DEALER (Hàng trên) - Tọa độ y=40
    for i, card in enumerate(d_hand):
        img = Image.open(f"{PATH}matsau.png").convert("RGBA") if hide_dealer else get_card_img(card)
        card_img = img.resize((100, 140))
        bg.paste(card_img, (300 + i*110, 40), card_img)
        
    # 2. HÀNG BÀI CHUNG (Hàng giữa) - Tọa độ y=220
    # Stage sẽ quyết định hiện bao nhiêu lá (Flop: 3, Turn: 4, River: 5)
    for i in range(5):
        if i < len(community):
            img = get_card_img(community[i])
        else:
            img = Image.open(f"{PATH}matsau.png").convert("RGBA").resize((100, 140)) # Ô chờ
        
        card_img = img.resize((100, 140))
        bg.paste(card_img, (120 + i*110, 220), card_img)

    # 3. HÀNG PLAYER (Hàng dưới) - Tọa độ y=400
    for i, card in enumerate(p_hand):
        img = get_card_img(card).resize((100, 140))
        bg.paste(img, (300 + i*110, 400), img)
    
    buf = io.BytesIO()
    bg.save(buf, format="PNG")
    buf.seek(0)
    return buf

