import discord
import io
import random
from .factory import render_table, render_dice_result, render_poker_table

CHIP = "🪙"

class BaseGameView(discord.ui.View):
    """Lớp nền để dùng chung hàm update cho các game"""
    def __init__(self, user_id, timeout=60):
        super().__init__(timeout=timeout)
        self.user_id = user_id

    async def update_state(self, interaction: discord.Interaction, msg: str = None, render_func=None, func_args=None):
        # 1. Defer ngay lập tức để tránh lỗi timeout 3s
        if not interaction.response.is_done():
            await interaction.response.defer()
        
        # 2. Xử lý render (Việc nặng thực hiện ở đây)
        if render_func:
            img_data = render_func(*func_args)
            file = discord.File(fp=img_data, filename="result.png")
            
            # 3. Cập nhật tin nhắn gốc bằng edit_original_response
            await interaction.edit_original_response(
                content=msg,
                attachments=[file],
                view=self
            )
        else:
            await interaction.edit_original_response(content=msg, view=self)

class PokerView(BaseGameView):
    def __init__(self, user_id, bet, engine, update_func, log_history):
        super().__init__(user_id)
        self.bet, self.engine, self.update_chips = bet, engine, update_func
        self.log_game_history = log_history
        
        # Khởi tạo bộ bài
        game = self.engine() # Tạo instance deck mới
        self.p_hand = game.draw(2)
        self.d_hand = game.draw(2)
        self.full_community = game.draw(5)
        self.current_community = []
        self.stage_idx = 0 # 0: Pre-flop, 1: Flop, 2: Turn, 3: River
        self.stages = ["PRE-FLOP", "FLOP", "TURN", "RIVER"]

    @discord.ui.button(label="Theo Bài (Next)", style=discord.ButtonStyle.green)
    async def next_stage(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id: return
        
        self.stage_idx += 1
        
        if self.stage_idx == 1: self.current_community = self.full_community[:3]
        elif self.stage_idx == 2: self.current_community = self.full_community[:4]
        elif self.stage_idx == 3: self.current_community = self.full_community[:5]
        
        if self.stage_idx < 4:
            msg = f"💎 **POKER** | Giai đoạn: **{self.stages[self.stage_idx]}**"
            await self.update_state(interaction, msg=msg, render_func=render_poker_table, 
                                   func_args=(self.p_hand, self.d_hand, self.current_community, self.stages[self.stage_idx], True))
        else:
            # Tự động chuyển sang Showdown khi hết vòng River
            await self.showdown(interaction)

    @discord.ui.button(label="Bỏ Bài (Fold)", style=discord.ButtonStyle.red)
    async def fold(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id: return
        self.clear_items()
        self.log_game_history(self.user_id, "Poker", -self.bet, "FOLD")
        await interaction.response.edit_message(content=f" **{interaction.user.name}** đã bỏ bài. Mất cược!", view=None, attachments=[])

    async def showdown(self, interaction: discord.Interaction):
        self.clear_items()
        res, rank_id = self.engine.evaluate_poker_winner(self.p_hand, self.d_hand, self.full_community)
        
        rank_names = ["Bài Cao", "Một Đôi", "Hai Đôi", "Sám Cô", "Sảnh", "Thùng", "Cù Lũ", "Tứ Quý", "Sảnh Thùng", "Thùng Phá Sảnh"]
        p_rank = rank_names[self.engine.get_poker_rank(self.p_hand + self.full_community)[0]]
        
        change_amount = 0
        if res == "WIN":
            msg = f"**THẮNG!** Bạn có **{p_rank}** | +{self.bet * 2:,} {CHIP}"
            self.update_chips(self.user_id, self.bet * 2)
            change_amount = self.bet
        elif res == "LOSE":
            msg = f"**NHÀ CÁI THẮNG!** Nhà cái thắng | -{self.bet:,} {CHIP}"
            change_amount = -self.bet
        else:
            msg = f"**HÒA!** Hoàn trả cược"
            self.update_chips(self.user_id, self.bet)

        self.log_game_history(self.user_id, "Poker", change_amount, f"SHOWDOWN ({p_rank})")
        await self.update_state(interaction, msg=msg, render_func=render_poker_table, 
                               func_args=(self.p_hand, self.d_hand, self.full_community, "SHOWDOWN", False))

class BJView(BaseGameView):
    def __init__(self, user_id, p_hand, d_hand, engine, bet, update_func, log_history):
        super().__init__(user_id)
        self.p_hand, self.d_hand = p_hand, d_hand
        self.engine, self.bet, self.update_chips = engine, bet, update_func
        self.log_game_history = log_history # Lưu hàm ghi lịch sử vào view

    @discord.ui.button(label="Rút (Hit)", style=discord.ButtonStyle.green)
    async def hit(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id: return
        
        self.p_hand.append(self.engine.draw(1)[0])
        ps = self.engine.calc_points_bj(self.p_hand)
        
        # Kiểm tra nếu người chơi Quắc ngay khi rút
        if ps > 21:
            self.clear_items()
            msg = f"***THUA (QUẮC)!*** ({ps} điểm)"
            # Ghi lịch sử: Thua nên change_amount là -bet
            self.log_game_history(self.user_id, "Blackjack", -self.bet, "THUA (QUẮC)")
            await self.update_state(interaction, msg=msg, render_func=render_table, func_args=(self.p_hand, self.d_hand, False))
        else:
            await self.update_state(interaction, render_func=render_table, func_args=(self.p_hand, self.d_hand, True))

    @discord.ui.button(label="Dừng (Stand)", style=discord.ButtonStyle.red)
    async def stand(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id: return
        self.clear_items()
        
        while self.engine.calc_points_bj(self.d_hand) < 17:
            self.d_hand.append(self.engine.draw(1)[0])
            
        ps = self.engine.calc_points_bj(self.p_hand)
        ds = self.engine.calc_points_bj(self.d_hand)
        
        result_type = ""
        change_amount = 0

        if ds > 21:
            msg = f"***THẮNG!*** Nhà cái Quắc ({ds}) | +{self.bet:,} {CHIP}"
            self.update_chips(self.user_id, self.bet * 2)
            result_type, change_amount = "THẮNG", self.bet
        elif ps > ds:
            msg = f"***THẮNG!*** ({ps} vs {ds}) | +{self.bet:,} {CHIP}"
            self.update_chips(self.user_id, self.bet * 2)
            result_type, change_amount = "THẮNG", self.bet
        elif ps < ds: 
            msg = f"***NHÀ CÁI THẮNG!*** ({ps} vs {ds})"
            result_type, change_amount = "THUA", -self.bet
        else:
            msg = f"***HÒA!*** ({ps} vs {ds}) | Hoàn trả vốn"
            self.update_chips(self.user_id, self.bet)
            result_type, change_amount = "HÒA", 0

        # Ghi nhật ký ván đấu sau khi có kết quả Stand
        self.log_game_history(self.user_id, "Blackjack", change_amount, result_type)

        await self.update_state(interaction, msg=msg, render_func=render_table, func_args=(self.p_hand, self.d_hand, False))

class BaccaratView(BaseGameView):
    def __init__(self, user_id, p_hand, d_hand, bet, engine, update_func, log_history):
        super().__init__(user_id)
        self.p_hand = p_hand
        self.d_hand = d_hand
        self.bet = bet
        self.engine = engine
        self.update_chips = update_func
        self.log_game_history = log_history

    @discord.ui.button(label="Mở Bài", style=discord.ButtonStyle.blurple)
    async def show(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id: 
            return await interaction.response.send_message("Đây không phải ván bài của bạn!", ephemeral=True)
            
        self.clear_items()
        
        pp = self.engine.calc_points_baccarat(self.p_hand)
        dp = self.engine.calc_points_baccarat(self.d_hand)
        
        # Thiết lập thông tin để ghi vào History
        change_amount = 0 # <--- Khởi tạo
        status_text = ""  # <--- Khởi tạo
        
        if pp > dp:
            msg = f"***THẮNG!*** ({pp} vs {dp}) | +{self.bet:,} {CHIP}"
            self.update_chips(self.user_id, self.bet * 2) 
            change_amount, status_text = self.bet, "THẮNG" # <--- Gán giá trị
        elif pp < dp: 
            msg = f"***NHÀ CÁI THẮNG***! ({pp} vs {dp})"
            change_amount, status_text = -self.bet, "THUA" # <--- Gán giá trị
        else:
            msg = f"***HÒA!*** ({pp} vs {dp}) | Hoàn trả vốn"
            self.update_chips(self.user_id, self.bet)
            change_amount, status_text = 0, "HÒA" # <--- Gán giá trị

        # --- QUAN TRỌNG: GỌI HÀM GHI LỊCH SỬ TẠI ĐÂY ---
        self.log_game_history(self.user_id, "Baccarat", change_amount, status_text) # <---

        # Cập nhật kết quả lên Discord
        await self.update_state(
            interaction, 
            msg=msg, 
            render_func=render_table, 
            func_args=(self.p_hand, self.d_hand, False)
        )

class TaiXiuView(BaseGameView):
    def __init__(self, user_id, bet_amount, engine, update_chips, log_history):
        super().__init__(user_id)
        self.bet = bet_amount
        self.engine = engine  # Phải có cái này để gọi check_taixiu
        self.update_chips = update_chips
        self.log_game_history = log_history # Truyền hàm ghi lịch sử vào đây

    async def process_bet(self, interaction: discord.Interaction, choice: str):
        if interaction.user.id != self.user_id: 
            return await interaction.response.send_message("Không phải phiên của bạn!", ephemeral=True)
            
        self.clear_items() 
        
        # 1. Lắc xúc xắc & Kiểm tra kết quả
        dices = [random.randint(1, 6) for _ in range(3)]
        total = sum(dices)
        result = self.engine.check_taixiu(dices) 
        
        is_win = (choice == result)
        status_text = "THUA"
        change_amount = -self.bet # Mặc định là lỗ số tiền đã cược
        
        # 2. XỬ LÝ JACKPOT (3 CON 6)
        if result == "jackpot":
            with open(DATA_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            last_win_str = data["system"].get("last_jackpot_win", "2026-01-01 00:00:00")
            last_win_dt = datetime.strptime(last_win_str, "%Y-%m-%d %H:%M:%S")
            
            # Kiểm tra hồi chiêu 24h
            if datetime.now() > last_win_dt + timedelta(hours=24):
                jackpot_pool = data["system"]["jackpot_pool"]
                self.update_chips(self.user_id, jackpot_pool) 
                
                # Lưu thời gian nổ hũ mới
                data["system"]["last_jackpot_win"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                with open(DATA_PATH, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=4)
                
                status_text = "🎊 JACKPOT 🎊"
                change_amount = jackpot_pool
                await interaction.channel.send(f"📢 **NỔ HŨ!!!** {interaction.user.mention} đã hốt trọn **{jackpot_pool:,}** {CHIP}!")
            else:
                status_text = "THUA (BÃO)" # Đang hồi chiêu nên tính là Bão thường
                change_amount = -self.bet

        # 3. THẮNG/THUA THƯỜNG
        elif is_win:
            self.update_chips(self.user_id, self.bet * 2) 
            status_text = "THẮNG"
            change_amount = self.bet # Tiền lãi
        
        # 4. GHI NHẬT KÝ (History)
        self.log_game_history(self.user_id, "Tài Xỉu", change_amount, status_text)
        
        # 5. HIỂN THỊ KẾT QUẢ
        msg = f"**{status_text}!** Kết quả: `{total}` - **{result.upper()}**"
        if is_win and result != "jackpot":
            msg += f" | +{self.bet:,} {CHIP}"

        await self.update_state(interaction, msg=msg, render_func=render_dice_result, func_args=(dices,))

    @discord.ui.button(label="TÀI (11-17)", style=discord.ButtonStyle.danger, custom_id="tai_btn")
    async def tai_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.process_bet(interaction, "tai")

    @discord.ui.button(label="XỈU (4-10)", style=discord.ButtonStyle.primary, custom_id="xiu_btn")
    async def xiu_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.process_bet(interaction, "xiu")
