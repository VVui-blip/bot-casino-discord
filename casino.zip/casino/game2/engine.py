import random
from datetime import datetime


class CasinoEngine:
    def __init__(self):
        self.suits = ['h', 'd', 'c', 's']
        self.ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
        self.deck = [f"{s}{r}" for s in self.suits for r in self.ranks]
        random.shuffle(self.deck)

    def draw(self, count=1):
        drawn = []
        for _ in range(count):
            if self.deck: 
                drawn.append(self.deck.pop())
        return drawn

    @staticmethod
    def get_poker_rank(five_cards):
        """
        Phan loai bo 5 la theo quy tac Poker Texas Hold'em
        Tra ve: (Cap_Bac, Danh_Sach_Gia_Tri_De_So_Sanh)
        """
        # Chuyen doi ky tu thanh gia tri so de tinh toan
        rank_map = {'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'J':11,'Q':12,'K':13,'A':14}
        
        # Lay gia tri va chat (VD: 'sA' -> val=14, suit='s')
        values = sorted([rank_map[c[1:]] for c in five_cards], reverse=True)
        suits = [c[0] for c in five_cards]
        
        # Kiem tra Thung (Flush) va Sanh (Straight)
        is_flush = len(set(suits)) == 1
        is_straight = len(set(values)) == 5 and (max(values) - min(values) == 4)
        
        # Dem so luong cac quan bai giong nhau
        counts = {v: values.count(v) for v in set(values)}
        sorted_counts = sorted(counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
        counts_list = [x[1] for x in sorted_counts]
        v_ranked = [x[0] for x in sorted_counts]

        # 1. Royal Flush & Straight Flush
        if is_straight and is_flush:
            return (9, v_ranked) if values[0] == 14 else (8, v_ranked)
        # 2. Four of a Kind (Tu quy)
        if counts_list == [4, 1]: return (7, v_ranked)
        # 3. Full House (Cu lu)
        if counts_list == [3, 2]: return (6, v_ranked)
        # 4. Flush (Thung)
        if is_flush: return (5, v_ranked)
        # 5. Straight (Sanh)
        if is_straight: return (4, v_ranked)
        # 6. Three of a Kind (Sam co)
        if counts_list == [3, 1, 1]: return (3, v_ranked)
        # 7. Two Pair (Hai doi)
        if counts_list == [2, 2, 1]: return (2, v_ranked)
        # 8. One Pair (Mot doi)
        if counts_list == [2, 1, 1, 1]: return (1, v_ranked)
        # 9. High Card (Bai cao)
        return (0, v_ranked)

    @staticmethod
    def evaluate_poker_winner(player_hand, dealer_hand, community_cards):
        """
        Tim bo 5 la manh nhat tu 7 la va so sanh Player vs Dealer
        """
        import itertools
        
        def get_best_five(hand, community):
            all_7 = hand + community
            all_combos = list(itertools.combinations(all_7, 5))
            # Tim combo co rank cao nhat
            return max([CasinoEngine.get_poker_rank(c) for c in all_combos])

        p_best = get_best_five(player_hand, community_cards)
        d_best = get_best_five(dealer_hand, community_cards)

        if p_best > d_best: return "WIN", p_best[0]
        if p_best < d_best: return "LOSE", d_best[0]
        return "PUSH", p_best[0]

    @staticmethod
    def calc_points_bj(hand):
        """Tính điểm Blackjack chuẩn: Át linh hoạt 1/11"""
        score, aces = 0, 0
        vals = {'A':11,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'J':10,'Q':10,'K':10}
        for card in hand:
            # Lấy rank từ mã bài (VD: 'hA' -> 'A', 's10' -> '10')
            r = card[1:]
            score += vals[r]
            if r == 'A': 
                aces += 1
        
        # Nếu quá 21 và còn Át, trừ bớt 10 để Át tính là 1 điểm
        while score > 21 and aces:
            score -= 10
            aces -= 1
        return score

    @staticmethod
    def determine_bj_winner(player_hand, dealer_hand):
        """Xác định thắng thua dựa trên điểm số thực tế"""
        p_score = CasinoEngine.calc_points_bj(player_hand)
        d_score = CasinoEngine.calc_points_bj(dealer_hand)
        
        # 1. KIỂM TRA QUẮC (BUST) ĐẦU TIÊN
        if p_score > 21:
            return "LOSE_BUST", -1
            
        # 2. KIỂM TRA BLACKJACK (2 lá đầu 21 điểm)
        is_p_bj = len(player_hand) == 2 and p_score == 21
        is_d_bj = len(dealer_hand) == 2 and d_score == 21

        if is_p_bj and not is_d_bj:
            return "BLACKJACK", 1.5
        if is_d_bj and not is_p_bj:
            return "DEALER_BJ", -1
            
        # 3. KIỂM TRA NHÀ CÁI QUẮC
        if d_score > 21:
            return "WIN_DEALER_BUST", 1

        # 4. SO ĐIỂM KHI KHÔNG AI QUẮC
        if p_score > d_score:
            return "WIN", 1
        elif p_score < d_score:
            return "LOSE", -1
        else:
            return "PUSH", 0

    @staticmethod
    def check_taixiu(dices):
        # 1. Kiểm tra Bão (3 con giống nhau)
        if dices[0] == dices[1] == dices[2]:
            # Nếu là 3 con 6 thì trả về 'jackpot', còn lại là 'bao'
            if dices[0] == 6:
                return "jackpot"
            return "bao" 
        
        # 2. Tính Tài Xỉu bình thường
        total = sum(dices)
        if 4 <= total <= 10:
            return "xiu"
        elif 11 <= total <= 17:
            return "tai"
        return "invalid"


    @staticmethod
    def calc_points_baccarat(hand):
        vals = {'A':1,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':0,'J':0,'Q':0,'K':0}
        return sum(vals[c[1:]] for c in hand) % 10

    @staticmethod
    def can_daily(last_daily_str):
        """Kiểm tra xem đã qua ngày mới chưa (so với mốc 00:00)"""
        if not last_daily_str:
            return True
        last_date = datetime.strptime(last_daily_str, "%Y-%m-%d").date()
        return datetime.now().date() > last_date